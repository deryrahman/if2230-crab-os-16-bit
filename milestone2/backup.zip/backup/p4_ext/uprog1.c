void printString(char*);
void terminate();

int main(){
	printString("Hello, world!\n\r\0");
	terminate();
}